
// custom js

let data = JSON.parse(localStorage.getItem("Categorydata"));

let row = '';

for (let i = 0; i < data.category.length; i++) {
    row += "<a href='#' class='nav-item nav-link' onclick='dcatdata(" + data.category[i].id + ")'>" + data.category[i].catname + "</a>";
}
document.getElementById("navbar-nav").innerHTML = row;


// Display product in website

let disproduct = JSON.parse(localStorage.getItem("ProductDetails"));

let row2 = '';

if (disproduct != null && disproduct.product.length > 0) {
    for (let i = 0; i < disproduct.product.length; i++) {

        row2 += `<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0" style="height:240px;">
                <img class="img-fluid w-100" src="${disproduct.product[i].img}" alt="" style="height:240px;">
            </div>
            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                <h6 class="text-truncate mb-3">${disproduct.product[i].name}</h6>
                <div class="d-flex justify-content-center">
                    <h6>₹${disproduct.product[i].price}</h6><h6 class="text-muted ml-2"><del>₹${disproduct.product[i].price}</del></h6>
                </div>
            </div>
            <div class="card-footer d-flex justify-content-between bg-light border">
                <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                <button href="" id='addtocartnum' class="btn btn-sm text-dark p-0" onclick='addtocart( ${disproduct.product[i].pid} )'><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</button>
            </div>
        </div>
    </div>`;

    }

    document.getElementById("productid").innerHTML = row2;
}

// Add to cart

addtocartdisplay();

function addtocart(id) {

    let data = JSON.parse(localStorage.getItem("ProductDetails"));

    let addtocartdata = JSON.parse(localStorage.getItem("addtocartdetail"));

    let addtocartsave = {};

    let addtocartsave2 = {};

    if (addtocartdata != null) {

        let cartData = addtocartdata.find(function (e) {
            return e.pid == id;
        })


        if (cartData != null) {

            for (let j = 0; j < addtocartdata.length; j++) {
                if (addtocartdata[j].pid == id) {
                    addtocartdata[j].qty += 1;
                    addtocartdata[j].price = parseInt(addtocartdata[j].qty * data.product[j].price)
                }

            }
            localStorage.setItem("addtocartdetail", JSON.stringify(addtocartdata));

        } else {
            //push
            for (let i = 0; i < data.product.length; i++) {

                if (id == data.product[i].pid) {
                    let len = addtocartdata.length;

                    addtocartsave = {

                        id: len + 1,
                        qty: data.product[i].qty,
                        name: data.product[i].name,
                        img: data.product[i].img,
                        price: data.product[i].price,
                        pid: data.product[i].pid,

                    }

                    document.getElementById("shopcount").innerHTML = len + 1;

                    addtocartdata.push(addtocartsave);
                    addtocartsave2 = addtocartdata;
                    localStorage.setItem("addtocartdetail", JSON.stringify(addtocartsave2));

                }

            }
        }



    } else {

        for (let i = 0; i < data.product.length; i++) {

            if (id == data.product[i].id) {

                addtocartsave = {


                    id: 1,
                    qty: data.product[i].qty,
                    name: data.product[i].name,
                    img: data.product[i].img,
                    price: data.product[i].price,
                    pid: data.product[i].pid

                };

                document.getElementById("shopcount").innerHTML = 1;

            }

        }

        localStorage.setItem("addtocartdetail", JSON.stringify([addtocartsave]));

    }
    addtocartdisplay();
}

function addtocartdisplay() {

    let data = JSON.parse(localStorage.getItem("addtocartdetail"));

    let row3 = '';

    let qety = 0;

    let sum = 0;

    if (data != null) {
        row3 += "<tr class='border'>";
        row3 += "<th class='border border-end text-dark'><center>Id</center></th>";
        row3 += "<th class='border border-end text-dark'><center>Name</center></th>";
        row3 += "<th class='border border-end text-dark'><center>Product</center></th>";
        row3 += "<th class='border border-end text-dark'><center>Qty</center></th>";
        row3 += "<th class='border border-end text-dark'><center>Price</center></th>";
        row3 += "<th class='text-dark'><center>Action</center></th>";
        row3 += "</tr>";

        for (let i = 0; i < data.length; i++) {

            row3 += "<tr class='border'>";
            row3 += "<td class='border border-end text-dark'><center>" + data[i].id + "</center></td>";
            row3 += "<td class='border border-end text-dark'><center>" + data[i].name + "</center></td>";
            row3 += "<td class='border border-end'><center> <img src='" + data[i].img + "' id='addtocartimg'> </center></td>";
            row3 += "<td class='border border-end text-dark'><center>" + data[i].qty + "</center></td>";
            row3 += "<td class='border border-end'><center>" + "₹ " + data[i].price + "</center></td>";
            row3 += "<td><center> <input type='button' name='del' id='del' onclick='delcartdata(" + data[i].id + ")' value='Delete'></center></td>";
            row3 += "</tr>";

            sum += parseInt(data[i].price);

            qety += parseInt(data[i].qty);

        }

    }


    document.getElementById("shopcount").innerHTML = qety;

    row3 += "<td class='border border-end text-dark' style='font-weight: bold;' colspan='3'><center>Total Amount</center></td>";
    row3 += "<td colspan='2'><center>₹ " + sum + "</center></td>";

    document.getElementById("addtocart-table").innerHTML = row3;

}

// Delete cart data

function delcartdata(id) {

    let data = JSON.parse(localStorage.getItem("addtocartdetail"));

    if (data != null) {

        for (let i = 0; i < data.length; i++) {

            if (id == data[i].id) {

                let id2 = id - 1;
                data.splice(id2, 1);
                let j = 1;
                for (let i = 0; i < data.length; i++) {
                    data[i].id = j;
                    j++;
                }

                document.getElementById("shopcount").innerHTML = id - 1;

                localStorage.setItem("addtocartdetail", JSON.stringify(data));
                addtocartdisplay();

            }

        }

    }

    addtocartdisplay();

}

// category wise information


function dcatdata(id) {

    let data = JSON.parse(localStorage.getItem("ProductDetails"));

    let arr1 = [];

    let arr2 = [];

    if (data != null) {

        for (let i = 0; i < data.product.length; i++) {

            arr1.push(data.product[i]);

        }

    }

    arr2 = arr1.filter(checkproduct);

    function checkproduct(p) {

        return id == p.catid;

    }

    localStorage.setItem("categorywisedata", JSON.stringify(arr2));

    displayCategoryproduct();

}

// display category wise data information 


function displayCategoryproduct() {

    let disproduct = JSON.parse(localStorage.getItem("categorywisedata"));

    let row5 = '';

    if (disproduct != null && disproduct.length > 0) {
        for (let i = 0; i < disproduct.length; i++) {

            row5 += `<div class="col-lg-3 col-md-6 col-sm-12 pb-1">
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0" style="height:240px;">
                <img class="img-fluid w-100" src="${disproduct[i].img}" alt="" style="height:240px;">
            </div>
            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                <h6 class="text-truncate mb-3">${disproduct[i].name}</h6>
                <div class="d-flex justify-content-center">
                    <h6>₹${disproduct[i].price}</h6><h6 class="text-muted ml-2"><del>₹${disproduct[i].price}</del></h6>
                </div>
            </div>
            <div class="card-footer d-flex justify-content-between bg-light border">
                <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                <button href="" id='addtocartnum' class="btn btn-sm text-dark p-0" onclick='addtocart( ${disproduct[i].id} )'><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</button>
            </div>
        </div>
    </div>`;

        }

        document.getElementById("productid").innerHTML = row5;
    }

}

